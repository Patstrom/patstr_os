Following this tutorial: https://os.phil-opp.com/

# Build

Dependencies:

* xorriso (provided by libisoburn on arch linux)
* mtools

```bash
make
```

# Run

Dependencies

* qemu

```bash
make run
```
